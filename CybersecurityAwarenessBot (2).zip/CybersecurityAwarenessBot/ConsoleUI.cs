﻿using System;
using System.Threading;

namespace CybersecurityAwarenessBot
{
    public class ConsoleUI
    {
        public static void Header(string title)
        {
            Console.ForegroundColor = ConsoleColor.Yellow;

            Console.WriteLine();
            Console.WriteLine("==============================================================");
            Console.WriteLine($"                    {title}");
            Console.WriteLine("==============================================================");

            Console.ResetColor();
        }

        public static void BotMessage(string message)
        {
            Console.ForegroundColor = ConsoleColor.Green;

            Console.Write("Bot: ");

            foreach (char character in message)
            {
                Console.Write(character);
                Thread.Sleep(20);
            }

            Console.WriteLine();

            Console.ResetColor();
        }

        public static void UserMessage(string message)
        {
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine($"You: {message}");
            Console.ResetColor();
        }

        public static void ErrorMessage(string message)
        {
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine($"Error: {message}");
            Console.ResetColor();
        }

        public static void Divider()
        {
            Console.ForegroundColor = ConsoleColor.DarkGray;
            Console.WriteLine("--------------------------------------------------------------");
            Console.ResetColor();
        }
    }
}
