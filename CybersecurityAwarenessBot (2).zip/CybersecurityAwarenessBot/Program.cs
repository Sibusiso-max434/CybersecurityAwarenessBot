﻿using System;

namespace CybersecurityAwarenessBot
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Title = "Cybersecurity Awareness Bot";

            Chatbot chatbot = new Chatbot();

            chatbot.Start();
        }
    }
}
