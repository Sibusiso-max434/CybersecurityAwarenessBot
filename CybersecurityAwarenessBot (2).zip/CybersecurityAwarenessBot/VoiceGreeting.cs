﻿using System;
using System.IO;
using System.Media;

namespace CybersecurityAwarenessBot
{
    public class VoiceGreeting
    {
        public static void PlayGreeting()
        {
            string audioPath = Path.Combine(
                AppDomain.CurrentDomain.BaseDirectory,
                "Audio",
                "greeting.wav"
            );

            if (File.Exists(audioPath))
            {
                try
                {
            SoundPlayer player = new SoundPlayer(audioPath);
            player.PlaySync(); // Plays the audio before continuing
                }
                catch (Exception)
                {
                    Console.WriteLine("Unable to play the voice greeting.");
                }
            }
            else
            {
                Console.WriteLine("Voice greeting file was not found.");
            }
        }
    }
}
