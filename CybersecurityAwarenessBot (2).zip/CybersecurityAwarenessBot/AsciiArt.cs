﻿using System;

namespace CybersecurityAwarenessBot
{
    public class AsciiArt
    {
        public static void DisplayLogo()
        {
            Console.ForegroundColor = ConsoleColor.Cyan;

            Console.WriteLine();
            Console.WriteLine("==============================================================");
            Console.WriteLine("        ____                  _                      _        ");
            Console.WriteLine("       / ___| _   _  ___ _ __(_) |_ _   _ _ __ ___| |_      ");
            Console.WriteLine("      | |   | | | |/ __| '__| | __| | | | '__/ _ \\ __|     ");
            Console.WriteLine("      | |___| |_| | (__| |  | | |_| |_| | | |  __/ |_       ");
            Console.WriteLine("       \\____|\\__,_|\\___|_|  |_|\\__|\\__,_|_|  \\___|\\__|     ");
            Console.WriteLine();
            Console.WriteLine("             CYBERSECURITY AWARENESS BOT");
            Console.WriteLine("==============================================================");

            Console.ResetColor();
            Console.WriteLine();
        }
    }
}
