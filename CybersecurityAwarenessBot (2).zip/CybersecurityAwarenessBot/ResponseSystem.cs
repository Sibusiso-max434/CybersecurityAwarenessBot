﻿using System;

namespace CybersecurityAwarenessBot
{
    public class ResponseSystem
    {
        public static string GetResponse(string question)
        {
            question = question.ToLower().Trim();

            if (question.Contains("how are you"))
            {
                return "I'm doing great! I'm ready to help you stay safe online.";
            }

            if (question.Contains("purpose") ||
                question.Contains("what do you do"))
            {
                return "My purpose is to teach you about cybersecurity and help you stay safe online.";
            }

            if (question.Contains("what can i ask") ||
                question.Contains("help"))
            {
                return "You can ask me about passwords, phishing, safe browsing, scams and other cybersecurity topics.";
            }

            if (question.Contains("password"))
            {
                return "Use a strong and unique password for every account. Consider using a password manager and enable multi-factor authentication.";
            }

            if (question.Contains("phishing"))
            {
                return "Phishing is a scam where criminals pretend to be trustworthy people or organisations to steal information. Avoid suspicious links and verify the sender.";
            }

            if (question.Contains("safe browsing") ||
                question.Contains("browsing"))
            {
                return "For safe browsing, use trusted websites, check the URL carefully, avoid suspicious downloads and keep your browser updated.";
            }

            if (question.Contains("scam"))
            {
                return "Be careful with unexpected messages asking for money, passwords or personal information. Verify requests before taking action.";
            }

            if (question.Contains("hack"))
            {
                return "Never attempt to access systems without permission. Learn cybersecurity through legal and ethical security testing.";
            }

            return "I didn't quite understand that. Could you rephrase your question?";
        }
    }
}
