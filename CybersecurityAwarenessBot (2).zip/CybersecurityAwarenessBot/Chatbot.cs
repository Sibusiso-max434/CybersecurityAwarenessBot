﻿using System;

namespace CybersecurityAwarenessBot
{
    public class Chatbot
    {
        private string userName;

        public void Start()
        {
            Console.Clear();

            // Display ASCII logo
            AsciiArt.DisplayLogo();

            // Play voice greeting
            VoiceGreeting.PlayGreeting();

            ConsoleUI.Header("WELCOME");

            AskForName();

            ConsoleUI.BotMessage(
                $"Nice to meet you, {userName}! I'm the Cybersecurity Awareness Bot."
            );

            ConsoleUI.BotMessage(
                "I can help you learn about passwords, phishing, scams and safe browsing."
            );

            ConsoleUI.Divider();

            StartConversation();
        }

        private void AskForName()
        {
            while (true)
            {
                Console.ForegroundColor = ConsoleColor.Cyan;
                Console.Write("Please enter your name: ");
                Console.ResetColor();

                string name = Console.ReadLine();

                if (InputValidator.IsValidName(name))
                {
                    userName = name.Trim();
                    break;
                }

                ConsoleUI.ErrorMessage(
                    "Name cannot be empty. Please enter your name."
                );
            }
        }

        private void StartConversation()
        {
            while (true)
            {
                Console.ForegroundColor = ConsoleColor.Cyan;
                Console.WriteLine();
                Console.Write($"{userName}: ");
                Console.ResetColor();

                string question = Console.ReadLine();

                if (question.Equals("exit", StringComparison.OrdinalIgnoreCase))
                {
                    ConsoleUI.BotMessage(
                        $"Goodbye {userName}! Stay safe online."
                    );

                    break;
                }

                if (!InputValidator.IsValidQuestion(question))
                {
                    ConsoleUI.ErrorMessage(
                        "Please enter a question."
                    );

                    continue;
                }

                string response = ResponseSystem.GetResponse(question);

                ConsoleUI.BotMessage(response);
            }
        }
    }
}
