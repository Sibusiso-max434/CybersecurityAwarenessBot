﻿using System;

namespace CybersecurityAwarenessBot
{
    public class InputValidator
    {
        public static bool IsValidName(string name)
        {
            return !string.IsNullOrWhiteSpace(name);
        }

        public static bool IsValidQuestion(string question)
        {
            return !string.IsNullOrWhiteSpace(question);
        }
    }
}
